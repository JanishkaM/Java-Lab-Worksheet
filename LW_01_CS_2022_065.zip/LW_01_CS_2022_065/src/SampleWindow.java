import javax.swing.*;

public class SampleWindow {
    public static void main(String[] args) {
        JFrame myFrame = new JFrame();
        myFrame.setVisible(true);
        myFrame.setSize(1200, 800);
        myFrame.setTitle("My Frame");
        myFrame.setName("My Frame Name");
    }
}
