import javax.swing.*;

public class Q4 {
    public static void main(String[] args) {
        JFrame window = new JFrame();
        window.setSize(300, 200);
        window.setVisible(true);
        window.setTitle("My First Frame");
        window.setLocation(100, 50);
    }
}
